-- Создание базы данных
CREATE DATABASE IF NOT EXISTS canteen_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE canteen_db;

-- Таблица пользователей (улучшенная)
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'user') DEFAULT 'user',
    phone VARCHAR(20),
    avatar VARCHAR(255) DEFAULT 'default.jpg',
    is_active BOOLEAN DEFAULT TRUE,
    email_verified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL,
    INDEX idx_email (email),
    INDEX idx_role (role)
) ENGINE=InnoDB;

-- Таблица категорий (новая - нормализация)
CREATE TABLE categories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) NOT NULL UNIQUE,
    slug VARCHAR(50) NOT NULL UNIQUE,
    icon VARCHAR(100),
    sort_order INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE
) ENGINE=InnoDB;

-- Таблица товаров (улучшенная)
CREATE TABLE products (
    id INT PRIMARY KEY AUTO_INCREMENT,
    category_id INT NOT NULL,
    name VARCHAR(150) NOT NULL,
    slug VARCHAR(150) NOT NULL UNIQUE,
    description TEXT,
    composition TEXT,
    price DECIMAL(10, 2) NOT NULL,
    old_price DECIMAL(10, 2),
    weight DECIMAL(10, 2) NOT NULL,
    unit ENUM('g', 'ml', 'piece') DEFAULT 'g',
    image_path VARCHAR(255),
    calories INT,
    proteins DECIMAL(5, 2),
    fats DECIMAL(5, 2),
    carbs DECIMAL(5, 2),
    is_active BOOLEAN DEFAULT TRUE,
    is_popular BOOLEAN DEFAULT FALSE,
    is_discount BOOLEAN DEFAULT FALSE,
    is_recommended BOOLEAN DEFAULT FALSE,
    stock_quantity INT DEFAULT 0,
    views_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE,
    INDEX idx_category (category_id),
    INDEX idx_active (is_active),
    INDEX idx_popular (is_popular),
    FULLTEXT KEY ft_search (name, description)
) ENGINE=InnoDB;

-- Таблица заказов (улучшенная)
CREATE TABLE orders (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    order_number VARCHAR(20) NOT NULL UNIQUE,
    total_amount DECIMAL(10, 2) NOT NULL,
    status ENUM('new', 'confirmed', 'preparing', 'ready', 'completed', 'cancelled') DEFAULT 'new',
    payment_method ENUM('cash', 'card', 'online') DEFAULT 'cash',
    payment_status ENUM('pending', 'paid', 'refunded') DEFAULT 'pending',
    delivery_type ENUM('pickup', 'delivery') DEFAULT 'pickup',
    delivery_address TEXT,
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user (user_id),
    INDEX idx_status (status),
    INDEX idx_created (created_at)
) ENGINE=InnoDB;

-- Таблица позиций заказа
CREATE TABLE order_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    price_at_moment DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    INDEX idx_order (order_id),
    INDEX idx_product (product_id)
) ENGINE=InnoDB;

-- Таблица отзывов (улучшенная)
CREATE TABLE reviews (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment TEXT,
    is_approved BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    INDEX idx_product (product_id),
    INDEX idx_rating (rating),
    UNIQUE KEY unique_user_product (user_id, product_id)
) ENGINE=InnoDB;

-- Таблица избранного (новая)
CREATE TABLE favorites (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    UNIQUE KEY unique_favorite (user_id, product_id)
) ENGINE=InnoDB;

-- Таблица поставок
CREATE TABLE supplies (
    id INT PRIMARY KEY AUTO_INCREMENT,
    doc_number VARCHAR(50) NOT NULL UNIQUE,
    supplier_name VARCHAR(150) NOT NULL,
    supplier_contact VARCHAR(150),
    supply_date DATE NOT NULL,
    total_sum DECIMAL(10, 2) NOT NULL,
    status ENUM('pending', 'received', 'cancelled') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_date (supply_date)
) ENGINE=InnoDB;

-- Таблица позиций поставок
CREATE TABLE supply_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    supply_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity DECIMAL(10, 2) NOT NULL,
    price_per_unit DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (supply_id) REFERENCES supplies(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Вставка категорий
INSERT INTO categories (name, slug, icon, sort_order) VALUES
('Все', 'all', '🍽️', 0),
('Горячее', 'hot', '🍖', 1),
('Супы', 'soup', '🍜', 2),
('Выпечка', 'bakery', '🥖', 3),
('Напитки', 'drink', '☕', 4),
('Салаты', 'salad', '🥗', 5),
('Десерты', 'dessert', '🍰', 6);

-- Создание администратора (пароль: admin123)
INSERT INTO users (full_name, email, password, role, is_active, email_verified) VALUES
('Администратор', 'admin@canteen.ru', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', TRUE, TRUE);

-- Примеры товаров
INSERT INTO products (category_id, name, slug, description, composition, price, old_price, weight, image_path, is_popular, is_discount) VALUES
(2, 'Пельмени с мясом', 'pelmeni-meat', 'Настоящая классика на вашем столе. Наши пельмени приготовлены по традиционному рецепту, где главное — это баланс вкуса и качества ингредиентов.', 'Мука пшеничная, говядина, свинина, лук, соль, перец', 189.00, NULL, 500, 'pelmeni.jpg', TRUE, FALSE),
(2, 'Котлета по-киевски', 'kotleta-kievskaya', 'Классическое блюдо с сочной начинкой из сливочного масла и зелени', 'Куриное филе, масло сливочное, зелень, панировочные сухари', 245.00, 299.00, 250, 'kotleta.jpg', TRUE, TRUE),
(3, 'Борщ украинский', 'borsch', 'Наваристый борщ со сметаной и пампушками', 'Свекла, капуста, картофель, морковь, мясо, сметана', 165.00, NULL, 350, 'borsch.jpg', TRUE, FALSE);

-- Триггер для подсчета среднего рейтинга
DELIMITER $$
CREATE TRIGGER update_product_rating AFTER INSERT ON reviews
FOR EACH ROW
BEGIN
    UPDATE products 
    SET views_count = (SELECT AVG(rating) FROM reviews WHERE product_id = NEW.product_id)
    WHERE id = NEW.product_id;
END$$
DELIMITER ;

-- ==================== ТЕСТОВЫЕ ДАННЫЕ ====================

-- Вставка дополнительных товаров с полным описанием
INSERT INTO products (category_id, name, slug, description, composition, price, old_price, weight, unit, image_path, calories, proteins, fats, carbs, is_active, is_popular, is_discount, is_recommended, stock_quantity) VALUES

-- Горячие блюда
(2, 'Пельмени с мясом', 'pelmeni-meat', 
'Настоящая классика на вашем столе. Наши пельмени приготовлены по традиционному рецепту, где главное — это баланс вкуса и качества ингредиентов. В начинке используется только свежая говядина и свинина, приправленные черным перцем и луком для сочности. Тонкое тесто из высококачественной муки не разваривается при варке, сохраняя внутри весь мясной сок и аромат специй. Идеальный выбор для сытного обеда или ужина, когда хочется чего-то домашнего и вкусного.',
'Мука пшеничная высшего сорта, говядина, свинина, лук репчатый, вода питьевая, соль поваренная, перец черный молотый',
189.00, NULL, 500, 'g', 'pelmeni.jpg', 
250, 12.5, 8.3, 28.4, 1, 1, 0, 1, 50),

(2, 'Котлета по-киевски', 'kotleta-kievskaya',
'Изысканное блюдо, которое покорило сердца гурманов по всему миру. Нежное куриное филе обволакивает тающую начинку из сливочного масла с зеленью. Каждый кусочек — это взрыв вкуса: хрустящая золотистая корочка уступает место сочному мясу, а масло с укропом и петрушкой разливается по тарелке ароматной лужицей. Котлета обжарена до идеальной степени готовности, чтобы панировка была хрустящей, а внутри филе оставалось невероятно нежным.',
'Филе куриное, масло сливочное 82%, укроп свежий, петрушка, панировочные сухари, яйцо куриное, мука пшеничная, соль, специи',
245.00, 299.00, 250, 'g', 'kotleta.jpg',
320, 22.0, 18.5, 15.2, 1, 1, 1, 1, 30),

(2, 'Куриные крылышки BBQ', 'wings-bbq',
'Сочные куриные крылышки в фирменном соусе барбекю — это сочетание дымного аромата, сладковатых ноток и легкой остринки. Крылышки маринуются в течение нескольких часов, затем запекаются до золотистой корочки и щедро поливаются домашним BBQ-соусом. Мясо легко отделяется от косточки, а соус пропитывает каждый кусочек. Отличный выбор для тех, кто любит сочетание сладкого и острого вкусов.',
'Крылышки куриные, соус BBQ (томатная паста, мед, горчица, чеснок, специи), масло растительное, соль, перец',
199.00, NULL, 400, 'g', 'wings.jpg',
280, 18.0, 15.0, 12.0, 1, 1, 0, 0, 40),

-- Супы
(3, 'Борщ украинский', 'borsch',
'Наваристый борщ, приготовленный по классическому украинскому рецепту — это настоящее произведение кулинарного искусства. Насыщенный мясной бульон с говядиной на кости варится несколько часов, чтобы раскрыть всю глубину вкуса. Свекла придает супу характерный рубиновый цвет и сладковатую нотку, капуста добавляет текстуру, а чеснок и сало в зажарке — пикантность. Подается со сметаной и свежими пампушками с чесноком.',
'Говядина на кости, свекла, капуста белокочанная, картофель, морковь, лук репчатый, томатная паста, чеснок, сало, уксус, лавровый лист, перец, соль, сметана 20%',
165.00, NULL, 350, 'ml', 'borsch.jpg',
180, 8.5, 7.2, 18.5, 1, 1, 0, 1, 60),

(3, 'Солянка мясная сборная', 'solyanka',
'Густой, ароматный суп с богатым вкусом — настоящая классика русской кухни. В основе солянки лежит крепкий мясной бульон с тремя видами копченостей: грудинка, колбаса и ветчина создают неповторимый дымный аромат. Соленые огурцы и маслины добавляют пикантную кислинку, а томатная паста — насыщенный цвет. Каждая ложка — это настоящий праздник вкуса, который согревает и насыщает.',
'Говядина, колбаса копченая, грудинка копченая, ветчина, огурцы соленые, маслины, лук репчатый, морковь, томатная паста, каперсы, лимон, лавровый лист, специи, сметана',
195.00, NULL, 350, 'ml', 'solyanka.jpg',
220, 12.0, 10.5, 15.0, 1, 1, 0, 1, 45),

(3, 'Грибной крем-суп', 'mushroom-soup',
'Нежный, бархатистый суп-пюре из лесных грибов с добавлением сливок — это воплощение уюта в тарелке. Шампиньоны и белые грибы обжариваются с луком до золотистого цвета, затем томятся в ароматном бульоне и превращаются в однородную кремовую массу. Сливки придают супу нежность, а свежий тимьян — утонченный аромат. Подается с хрустящими гренками и веточкой зелени.',
'Шампиньоны, белые грибы сушеные, лук репчатый, чеснок, сливки 33%, масло сливочное, мука пшеничная, тимьян, петрушка, соль, перец, гренки',
175.00, 210.00, 300, 'ml', 'mushroom-soup.jpg',
150, 4.5, 8.0, 12.0, 1, 0, 1, 0, 35),

-- Выпечка
(4, 'Пирожки с капустой', 'pirozhki-cabbage',
'Домашние пирожки с хрустящей корочкой и сочной капустной начинкой — это вкус детства и уют бабушкиной кухни. Тесто готовится на живых дрожжах и выпекается до золотистого цвета. Начинка из тушеной капусты с луком и морковью томится на медленном огне, чтобы овощи стали мягкими и ароматными. Пирожки подаются теплыми, когда тесто еще мягкое, а начинка дымится.',
'Мука пшеничная, дрожжи прессованные, молоко, сахар, соль, масло растительное, капуста белокочанная, лук репчатый, морковь, масло сливочное, перец',
65.00, NULL, 120, 'g', 'pirozhki.jpg',
210, 5.5, 6.0, 32.0, 1, 1, 0, 0, 80),

(4, 'Круассан с шоколадом', 'croissant-chocolate',
'Французский круассан со множеством хрустящих слоев слоеного теста и нежной шоколадной начинкой внутри. Каждый слой теста пропитан сливочным маслом и создает неповторимую текстуру — снаружи хрустящую, внутри мягкую и воздушную. Бельгийский шоколад тает во рту, создавая идеальное сочетание с маслянистым тестом. Идеальный выбор для завтрака с кофе.',
'Мука пшеничная высшего сорта, масло сливочное 82%, молоко, дрожжи, сахар, соль, яйцо, шоколад темный 70%',
95.00, NULL, 90, 'g', 'croissant.jpg',
280, 6.0, 14.0, 32.0, 1, 1, 0, 1, 60),

-- Напитки
(5, 'Кофе Американо', 'coffee-americano',
'Классический черный кофе для истинных ценителей. Готовится из свежемолотых зерен 100% арабики средней обжарки. Эспрессо разбавляется горячей водой, чтобы получить насыщенный, но мягкий вкус без горечи. Идеально сбалансированная крепость и аромат с нотками шоколада и орехов. Подается в большой чашке, чтобы вы могли насладиться каждым глотком.',
'Кофе в зернах арабика, вода очищенная',
120.00, NULL, 300, 'ml', 'americano.jpg',
5, 0.2, 0.0, 0.0, 1, 1, 0, 0, 100),

(5, 'Морс клюквенный', 'mors',
'Освежающий напиток из северных ягод, приготовленный по домашнему рецепту. Клюква богата витамином С и антиоксидантами, а при правильном приготовлении сохраняет все свои полезные свойства. Морс имеет приятную кислинку и естественную сладость, подается охлажденным. Отличный выбор для тех, кто заботится о здоровье и любит натуральные напитки.',
'Клюква свежая, сахар, вода очищенная',
85.00, NULL, 400, 'ml', 'mors.jpg',
80, 0.1, 0.0, 20.0, 1, 0, 0, 1, 70),

-- Салаты
(6, 'Цезарь с курицей', 'caesar-chicken',
'Легендарный салат, который покорил весь мир своей простотой и изысканностью. Сочное куриное филе обжаривается на гриле с легкой дымкой, хрустящий салат Романо остается свежим и хрустящим, а пармезан добавляет пикантную соленость. Фирменный соус Цезарь с анчоусами, чесноком и лимоном связывает все ингредиенты воедино. Хрустящие гренки из белого хлеба добавляют текстуру.',
'Салат Романо, куриное филе гриль, сыр Пармезан, помидоры черри, гренки пшеничные, соус Цезарь (майонез, анчоусы, чеснок, лимонный сок, горчица), перец черный',
220.00, NULL, 280, 'g', 'caesar.jpg',
240, 18.0, 12.0, 15.0, 1, 1, 0, 1, 40),

(6, 'Греческий салат', 'greek-salad',
'Средиземноморская свежесть на вашей тарелке. Сочные помидоры, хрустящие огурцы, сладкий болгарский перец и красный лук создают идеальную основу. Маслины Каламата добавляют пикантность, а брынза — приятную соленость. Заправка из оливкового масла Extra Virgin с орегано и лимонным соком раскрывает все ароматы овощей. Простой, но невероятно вкусный салат, который переносит вас на берег Эгейского моря.',
'Томаты, огурцы свежие, перец болгарский, лук красный, маслины Каламата, сыр Фета, масло оливковое Extra Virgin, сок лимона, орегано сушеный, соль морская',
195.00, 235.00, 250, 'g', 'greek-salad.jpg',
180, 6.0, 12.0, 8.0, 1, 1, 1, 0, 45),

-- Десерты
(7, 'Чизкейк Нью-Йорк', 'cheesecake-ny',
'Классический американский десерт с нежной текстурой и богатым сливочным вкусом. Основа из песочного печенья создает хрустящий контраст с воздушной начинкой из сливочного сыра. Десерт имеет идеальный баланс сладости и легкой кислинки от сметаны. Выпекается на водяной бане для достижения бархатистой текстуры без трещин. Подается с ягодным соусом или свежими фруктами.',
'Сыр сливочный Philadelphia, сахар, яйца куриные, сметана 20%, ванильный экстракт, печенье песочное, масло сливочное, соус ягодный',
185.00, NULL, 150, 'g', 'cheesecake.jpg',
320, 7.0, 18.0, 32.0, 1, 1, 0, 1, 25),

(7, 'Тирамису', 'tiramisu',
'Итальянский десерт, название которого переводится как "подними меня вверх". И это действительно так — каждая ложка этого нежного лакомства поднимает настроение! Воздушный крем маскарпоне чередуется со слоями печенья Савоярди, пропитанного крепким эспрессо и ликером Амаретто. Какао-порошок сверху добавляет легкую горчинку. Десерт должен настояться в холодильнике, чтобы все вкусы соединились воедино.',
'Сыр Маскарпоне, печенье Савоярди, яйца куриные, сахар, кофе эспрессо, ликер Амаретто, какао-порошок',
210.00, NULL, 180, 'g', 'tiramisu.jpg',
290, 6.5, 16.0, 28.0, 1, 1, 0, 1, 30);

-- Вставка тестовых отзывов
INSERT INTO reviews (user_id, product_id, rating, comment, is_approved, created_at) VALUES
(1, 1, 5, 'Отличные пельмени! Как у бабушки. Мясо сочное, тесто не разваривается. Буду заказывать еще!', 1, NOW() - INTERVAL 3 DAY),
(1, 2, 5, 'Котлета просто восхитительная! Масло внутри растекается, очень вкусно. Рекомендую!', 1, NOW() - INTERVAL 5 DAY),
(1, 4, 4, 'Вкусный борщ, но хотелось бы побольше мяса. В целом хорошо.', 1, NOW() - INTERVAL 2 DAY),
(1, 11, 5, 'Цезарь просто огонь! Курица сочная, соус отличный, порция большая.', 1, NOW() - INTERVAL 1 DAY);

-- Обновление количества просмотров для популярности
UPDATE products SET views_count = 150 WHERE id = 1;
UPDATE products SET views_count = 120 WHERE id = 2;
UPDATE products SET views_count = 95 WHERE id = 4;
UPDATE products SET views_count = 88 WHERE id = 11;
UPDATE products SET views_count = 76 WHERE id = 14;

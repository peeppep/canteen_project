<?php
session_start();

/**
 * Проверка авторизации пользователя
 */
function checkAuth() {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        echo json_encode([
            'success' => false,
            'message' => 'Необходима авторизация'
        ]);
        exit();
    }
    
    return [
        'id' => $_SESSION['user_id'],
        'name' => $_SESSION['user_name'],
        'email' => $_SESSION['user_email'],
        'role' => $_SESSION['user_role']
    ];
}

/**
 * Проверка прав администратора
 */
function checkAdmin() {
    $user = checkAuth();
    
    if ($user['role'] !== 'admin') {
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'message' => 'Доступ запрещен. Требуются права администратора.'
        ]);
        exit();
    }
    
    return $user;
}

/**
 * Получение текущего пользователя (без выхода при отсутствии авторизации)
 */
function getCurrentUser() {
    if (isset($_SESSION['user_id'])) {
        return [
            'id' => $_SESSION['user_id'],
            'name' => $_SESSION['user_name'],
            'email' => $_SESSION['user_email'],
            'role' => $_SESSION['user_role']
        ];
    }
    
    return null;
}

/**
 * Проверка владельца ресурса
 */
function checkOwnership($resourceUserId) {
    $user = checkAuth();
    
    if ($user['role'] !== 'admin' && $user['id'] != $resourceUserId) {
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'message' => 'Доступ запрещен. Вы можете управлять только своими данными.'
        ]);
        exit();
    }
    
    return $user;
}

/**
 * Установка данных пользователя в сессию
 */
function setUserSession($userId, $userName, $userEmail, $userRole) {
    $_SESSION['user_id'] = $userId;
    $_SESSION['user_name'] = $userName;
    $_SESSION['user_email'] = $userEmail;
    $_SESSION['user_role'] = $userRole;
    $_SESSION['login_time'] = time();
}

/**
 * Очистка сессии пользователя
 */
function clearUserSession() {
    session_unset();
    session_destroy();
}

/**
 * Проверка времени жизни сессии
 */
function checkSessionTimeout($timeout = 7200) { // 2 часа по умолчанию
    if (isset($_SESSION['login_time'])) {
        $elapsed = time() - $_SESSION['login_time'];
        
        if ($elapsed > $timeout) {
            clearUserSession();
            http_response_code(401);
            echo json_encode([
                'success' => false,
                'message' => 'Сессия истекла. Пожалуйста, войдите снова.'
            ]);
            exit();
        }
        
        // Обновляем время последней активности
        $_SESSION['login_time'] = time();
    }
}
?>

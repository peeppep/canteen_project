<?php
// Настройки безопасности
define('SITE_URL', 'http://localhost/canteen-project');
define('SESSION_LIFETIME', 7200); // 2 часа
define('CAPTCHA_LENGTH', 4);
define('ITEMS_PER_PAGE', 12);

// Пути
define('UPLOAD_PATH', __DIR__ . '/../../assets/images/products/');
define('MAX_FILE_SIZE', 5242880); // 5MB

// Разрешенные расширения файлов
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'webp']);

// Роли пользователей
define('ROLE_ADMIN', 'admin');
define('ROLE_USER', 'user');

// Настройки сессии
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_secure', 0); // Установить 1 для HTTPS
session_start();
?>

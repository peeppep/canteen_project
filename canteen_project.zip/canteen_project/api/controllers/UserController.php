<?php
session_start();
error_reporting(0);
ini_set('display_errors', 0);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../models/User.php';

function checkAuth() {
    if (!isset($_SESSION['user_id'])) {
        throw new Exception('Требуется авторизация');
    }
    return [
        'id' => $_SESSION['user_id'],
        'role' => $_SESSION['user_role'] ?? 'user'
    ];
}

function checkAdmin() {
    $user = checkAuth();
    if ($user['role'] !== 'admin') {
        throw new Exception('Требуются права администратора');
    }
    return $user;
}

try {
    $database = new Database();
    $db = $database->getConnection();
    $userModel = new User($db);

    $action = $_GET['action'] ?? '';
    
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);

    if (empty($data) && !empty($_POST)) {
        $data = $_POST;
    }

    switch ($action) {
        case 'list':
            checkAdmin();
            
            $search = $_GET['search'] ?? '';
            $role = $_GET['role'] ?? '';
            $limit = $_GET['limit'] ?? 100;
            
            $users = $userModel->getAll($search, $role, $limit);

            echo json_encode([
                'success' => true,
                'data' => $users
            ], JSON_UNESCAPED_UNICODE);
            break;

        case 'get':
            checkAdmin();
            
            $userId = $_GET['id'] ?? 0;
            
            if (!$userId) {
                throw new Exception('ID пользователя не указан');
            }

            $userData = $userModel->getById($userId);
            
            if (!$userData) {
                throw new Exception('Пользователь не найден');
            }

            echo json_encode([
                'success' => true,
                'data' => $userData
            ], JSON_UNESCAPED_UNICODE);
            break;

        case 'create':
            checkAdmin();
            
            $fullName = $data['full_name'] ?? '';
            $email = $data['email'] ?? '';
            $password = $data['password'] ?? '';
            $role = $data['role'] ?? 'user';
            $phone = $data['phone'] ?? '';

            if (empty($fullName) || empty($email) || empty($password)) {
                throw new Exception('Заполните все обязательные поля');
            }

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                throw new Exception('Некорректный email');
            }

            if (strlen($password) < 6) {
                throw new Exception('Пароль должен быть минимум 6 символов');
            }

            $result = $userModel->createByAdmin($fullName, $email, $password, $role, $phone);

            if (!$result['success']) {
                throw new Exception($result['message']);
            }

            echo json_encode([
                'success' => true,
                'message' => 'Пользователь успешно создан',
                'data' => ['id' => $result['user_id']]
            ], JSON_UNESCAPED_UNICODE);
            break;

        case 'update':
            checkAdmin();
            
            $userId = $data['id'] ?? 0;
            
            if (!$userId) {
                throw new Exception('ID пользователя не указан');
            }

            $updateData = [
                'full_name' => $data['full_name'] ?? '',
                'email' => $data['email'] ?? '',
                'phone' => $data['phone'] ?? '',
                'role' => $data['role'] ?? 'user',
                'is_active' => isset($data['is_active']) ? (int)$data['is_active'] : 1
            ];

            if (!empty($data['password'])) {
                if (strlen($data['password']) < 6) {
                    throw new Exception('Пароль должен быть минимум 6 символов');
                }
                $updateData['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
            }

            $result = $userModel->update($userId, $updateData);

            if ($result) {
                echo json_encode([
                    'success' => true,
                    'message' => 'Данные пользователя обновлены'
                ], JSON_UNESCAPED_UNICODE);
            } else {
                throw new Exception('Ошибка обновления данных');
            }
            break;

        case 'update_profile':
            $user = checkAuth();
            
            $userId = $user['id'];
            
            $updateData = [
                'full_name' => $data['full_name'] ?? '',
                'email' => $data['email'] ?? '',
                'phone' => $data['phone'] ?? ''
            ];

            if (!empty($data['password'])) {
                if (strlen($data['password']) < 6) {
                    throw new Exception('Пароль должен быть минимум 6 символов');
                }
                $updateData['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
            }

            $result = $userModel->update($userId, $updateData);

            if ($result) {
                $_SESSION['user_name'] = $updateData['full_name'];
                $_SESSION['user_email'] = $updateData['email'];
                
                echo json_encode([
                    'success' => true,
                    'message' => 'Профиль успешно обновлен'
                ], JSON_UNESCAPED_UNICODE);
            } else {
                throw new Exception('Ошибка обновления профиля');
            }
            break;

        case 'delete':
            checkAdmin();
            
            $userId = $data['id'] ?? $_GET['id'] ?? 0;
            
            if (!$userId) {
                throw new Exception('ID пользователя не указан');
            }

            if ($userId == $_SESSION['user_id']) {
                throw new Exception('Нельзя удалить собственный аккаунт');
            }

            $result = $userModel->delete($userId);

            if ($result) {
                echo json_encode([
                    'success' => true,
                    'message' => 'Пользователь удален'
                ], JSON_UNESCAPED_UNICODE);
            } else {
                throw new Exception('Ошибка удаления пользователя');
            }
            break;

        default:
            throw new Exception('Неизвестное действие: ' . $action);
    }

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>

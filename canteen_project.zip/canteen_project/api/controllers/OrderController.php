<?php
session_start();
error_reporting(0);
ini_set('display_errors', 0);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../models/Order.php';

function checkAuth() {
    if (!isset($_SESSION['user_id'])) {
        throw new Exception('Требуется авторизация');
    }
    return [
        'id' => $_SESSION['user_id'],
        'role' => $_SESSION['user_role'] ?? 'user'
    ];
}

function checkAdmin() {
    $user = checkAuth();
    if ($user['role'] !== 'admin') {
        throw new Exception('Требуются права администратора');
    }
    return $user;
}

try {
    $database = new Database();
    $db = $database->getConnection();
    $order = new Order($db);

    $action = $_GET['action'] ?? '';
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);

    if (empty($data) && !empty($_POST)) {
        $data = $_POST;
    }

    switch ($action) {
        case 'create':
            $user = checkAuth();
            
            if (!$data || !isset($data['items']) || empty($data['items'])) {
                throw new Exception('Корзина пуста');
            }

            $orderData = [
                'items' => $data['items'],
                'total_amount' => $data['total_amount'] ?? 0,
                'delivery_type' => $data['delivery_type'] ?? 'pickup',
                'delivery_address' => $data['delivery_address'] ?? '',
                'comment' => $data['comment'] ?? '',
                'payment_method' => $data['payment_method'] ?? 'cash'
            ];

            $result = $order->create($user['id'], $orderData);

            if ($result['success']) {
                echo json_encode([
                    'success' => true,
                    'message' => 'Заказ успешно создан',
                    'data' => [
                        'order_id' => $result['order_id'],
                        'order_number' => $result['order_number']
                    ]
                ], JSON_UNESCAPED_UNICODE);
            } else {
                throw new Exception($result['message']);
            }
            break;

        case 'list':
            $user = checkAuth();
            
            if ($user['role'] === 'admin') {
                $filters = [
                    'status' => $_GET['status'] ?? null,
                    'date_from' => $_GET['date_from'] ?? null,
                    'date_to' => $_GET['date_to'] ?? null
                ];
                $orders = $order->getAllOrders($filters);
            } else {
                $limit = $_GET['limit'] ?? 50;
                $orders = $order->getUserOrders($user['id'], $limit);
            }

            echo json_encode([
                'success' => true,
                'data' => $orders
            ], JSON_UNESCAPED_UNICODE);
            break;

        case 'get':
            $user = checkAuth();
            $orderId = $_GET['id'] ?? 0;

            if (!$orderId) {
                throw new Exception('ID заказа не указан');
            }

            $orderData = $order->getById($orderId, $user['role'] === 'admin' ? null : $user['id']);

            if (!$orderData) {
                throw new Exception('Заказ не найден');
            }

            echo json_encode([
                'success' => true,
                'data' => $orderData
            ], JSON_UNESCAPED_UNICODE);
            break;

        case 'statistics':
            $user = checkAuth();
            
            $userId = $user['role'] === 'admin' ? null : $user['id'];
            $stats = $order->getStatistics($userId);

            echo json_encode([
                'success' => true,
                'data' => $stats
            ], JSON_UNESCAPED_UNICODE);
            break;

        default:
            throw new Exception('Неизвестное действие');
    }

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>

<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../models/Product.php';

// Обработка ошибок
error_reporting(E_ALL);
ini_set('display_errors', 0);

try {
    $database = new Database();
    $db = $database->getConnection();
    $product = new Product($db);

    $action = $_GET['action'] ?? '';

    switch ($action) {
        case 'list':
            $category = $_GET['category'] ?? null;
            $search = $_GET['search'] ?? null;
            $popular = isset($_GET['popular']) ? true : false;
            $discount = isset($_GET['discount']) ? true : false;
            $limit = $_GET['limit'] ?? 50;

            if ($popular) {
                $result = $product->getPopular($limit);
            } elseif ($discount) {
                $result = $product->getDiscount($limit);
            } elseif ($search) {
                $result = $product->search($search, $limit);
            } elseif ($category) {
                $result = $product->getByCategory($category, $limit);
            } else {
                $result = $product->getAll($limit);
            }

            echo json_encode([
                'success' => true,
                'data' => $result
            ], JSON_UNESCAPED_UNICODE);
            break;

        case 'get':
            $id = $_GET['id'] ?? 0;
            
            if (!$id) {
                throw new Exception('ID товара не указан');
            }

            $result = $product->getById($id);
            
            if (!$result) {
                throw new Exception('Товар не найден');
            }

            echo json_encode([
                'success' => true,
                'data' => $result
            ], JSON_UNESCAPED_UNICODE);
            break;

        case 'reviews':
            $id = $_GET['id'] ?? 0;
            
            if (!$id) {
                throw new Exception('ID товара не указан');
            }

            $result = $product->getReviews($id);

            echo json_encode([
                'success' => true,
                'data' => $result
            ], JSON_UNESCAPED_UNICODE);
            break;

        default:
            throw new Exception('Неизвестное действие');
    }

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>

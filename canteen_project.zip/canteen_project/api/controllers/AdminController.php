<?php
require_once '../config/database.php';
require_once '../config/constants.php';
require_once '../models/User.php';
require_once '../models/Product.php';
require_once '../utils/response.php';
require_once '../utils/validator.php';

session_start();

// Проверка прав администратора
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    Response::error('Доступ запрещен', 403);
}

header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json; charset=utf-8');

$database = new Database();
$db = $database->getConnection();

$resource = $_GET['resource'] ?? '';
$action = $_GET['action'] ?? '';

switch ($resource) {
    case 'users':
        handleUsers($action);
        break;
    case 'products':
        handleProducts($action);
        break;
    case 'orders':
        handleOrders($action);
        break;
    case 'stats':
        getStatistics();
        break;
    default:
        Response::error('Неверный ресурс');
}

function handleUsers($action) {
    global $db;
    $user = new User($db);
    
    switch ($action) {
        case 'list':
            Response::success($user->getAll());
            break;
        case 'delete':
            $id = $_GET['id'] ?? 0;
            if ($user->delete($id)) {
                Response::success([], 'Пользователь удален');
            } else {
                Response::error('Ошибка удаления');
            }
            break;
        case 'toggle':
            $data = json_decode(file_get_contents("php://input"), true);
            $query = "UPDATE users SET is_active = :is_active WHERE id = :id";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':is_active', $data['is_active']);
            $stmt->bindParam(':id', $data['id']);
            if ($stmt->execute()) {
                Response::success([], 'Статус обновлен');
            } else {
                Response::error('Ошибка обновления');
            }
            break;
        default:
            Response::error('Неверное действие');
    }
}

function handleProducts($action) {
    global $db;
    $product = new Product($db);
    
    switch ($action) {
        case 'create':
            $data = json_decode(file_get_contents("php://input"), true);
            
            // Генерация slug
            $data['slug'] = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', transliterate($data['name']))));
            
            if ($product->create($data)) {
                Response::success([], 'Товар добавлен');
            } else {
                Response::error('Ошибка добавления');
            }
            break;
            
        case 'update':
            $data = json_decode(file_get_contents("php://input"), true);
            $id = $data['id'];
            unset($data['id']);
            
            if ($product->update($id, $data)) {
                Response::success([], 'Товар обновлен');
            } else {
                Response::error('Ошибка обновления');
            }
            break;
            
        case 'delete':
            $id = $_GET['id'] ?? 0;
            if ($product->delete($id)) {
                Response::success([], 'Товар удален');
            } else {
                Response::error('Ошибка удаления');
            }
            break;
            
        default:
            Response::error('Неверное действие');
    }
}

function handleOrders($action) {
    global $db;
    
    switch ($action) {
        case 'list':
            $query = "SELECT o.*, u.full_name, u.email 
                      FROM orders o
                      JOIN users u ON o.user_id = u.id
                      ORDER BY o.created_at DESC";
            $stmt = $db->prepare($query);
            $stmt->execute();
            Response::success($stmt->fetchAll());
            break;
            
        case 'update_status':
            $data = json_decode(file_get_contents("php://input"), true);
            $query = "UPDATE orders SET status = :status WHERE id = :id";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':status', $data['status']);
            $stmt->bindParam(':id', $data['id']);
            if ($stmt->execute()) {
                Response::success([], 'Статус обновлен');
            } else {
                Response::error('Ошибка обновления');
            }
            break;
            
        default:
            Response::error('Неверное действие');
    }
}

function getStatistics() {
    global $db;
    
    // Общая статистика
    $stats = [];
    
    // Количество пользователей
    $query = "SELECT COUNT(*) as count FROM users WHERE role = 'user'";
    $stmt = $db->query($query);
    $stats['users_count'] = $stmt->fetch()['count'];
    
    // Количество заказов
    $query = "SELECT COUNT(*) as count FROM orders";
    $stmt = $db->query($query);
    $stats['orders_count'] = $stmt->fetch()['count'];
    
    // Общая сумма продаж
    $query = "SELECT SUM(total_amount) as total FROM orders WHERE status = 'completed'";
    $stmt = $db->query($query);
    $stats['total_revenue'] = $stmt->fetch()['total'] ?? 0;
    
    // Количество товаров
    $query = "SELECT COUNT(*) as count FROM products WHERE is_active = 1";
    $stmt = $db->query($query);
    $stats['products_count'] = $stmt->fetch()['count'];
    
    // Последние заказы
    $query = "SELECT o.*, u.full_name 
              FROM orders o
              JOIN users u ON o.user_id = u.id
              ORDER BY o.created_at DESC
              LIMIT 5";
    $stmt = $db->query($query);
    $stats['recent_orders'] = $stmt->fetchAll();
    
    Response::success($stats);
}

function transliterate($str) {
    $rus = ['А', 'Б', 'В', 'Г', 'Д', 'Е', 'Ё', 'Ж', 'З', 'И', 'Й', 'К', 'Л', 'М', 'Н', 'О', 'П', 'Р', 'С', 'Т', 'У', 'Ф', 'Х', 'Ц', 'Ч', 'Ш', 'Щ', 'Ъ', 'Ы', 'Ь', 'Э', 'Ю', 'Я', 'а', 'б', 'в', 'г', 'д', 'е', 'ё', 'ж', 'з', 'и', 'й', 'к', 'л', 'м', 'н', 'о', 'п', 'р', 'с', 'т', 'у', 'ф', 'х', 'ц', 'ч', 'ш', 'щ', 'ъ', 'ы', 'ь', 'э', 'ю', 'я'];
    $lat = ['A', 'B', 'V', 'G', 'D', 'E', 'E', 'Zh', 'Z', 'I', 'Y', 'K', 'L', 'M', 'N', 'O', 'P', 'R', 'S', 'T', 'U', 'F', 'H', 'Ts', 'Ch', 'Sh', 'Sch', '', 'Y', '', 'E', 'Yu', 'Ya', 'a', 'b', 'v', 'g', 'd', 'e', 'e', 'zh', 'z', 'i', 'y', 'k', 'l', 'm', 'n', 'o', 'p', 'r', 's', 't', 'u', 'f', 'h', 'ts', 'ch', 'sh', 'sch', '', 'y', '', 'e', 'yu', 'ya'];
    return str_replace($rus, $lat, $str);
}
?>

<?php
session_start();
error_reporting(0);
ini_set('display_errors', 0);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../models/User.php';

// Простая проверка капчи
function validateCaptcha($input) {
    if (!isset($_SESSION['captcha_code'])) {
        return false;
    }
    return strtoupper($input) === strtoupper($_SESSION['captcha_code']);
}

try {
    $database = new Database();
    $db = $database->getConnection();
    $userModel = new User($db);

    $action = $_GET['action'] ?? '';
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);

    if (empty($data) && !empty($_POST)) {
        $data = $_POST;
    }

    switch ($action) {
        case 'register':
            $fullName = $data['full_name'] ?? '';
            $email = $data['email'] ?? '';
            $password = $data['password'] ?? '';
            $captcha = $data['captcha'] ?? '';

            if (empty($fullName) || empty($email) || empty($password)) {
                throw new Exception('Заполните все обязательные поля');
            }

            if (empty($captcha)) {
                throw new Exception('Введите код с картинки');
            }

            if (!validateCaptcha($captcha)) {
                throw new Exception('Неверный код с картинки');
            }

            $result = $userModel->register($fullName, $email, $password);

            echo json_encode($result, JSON_UNESCAPED_UNICODE);
            break;

        case 'login':
            $email = $data['email'] ?? '';
            $password = $data['password'] ?? '';

            if (empty($email) || empty($password)) {
                throw new Exception('Заполните все поля');
            }

            // КАПЧА НЕ ПРОВЕРЯЕТСЯ ПРИ ВХОДЕ - только при регистрации
            $result = $userModel->login($email, $password);

            if ($result['success']) {
                $_SESSION['user_id'] = $result['user']['id'];
                $_SESSION['user_role'] = $result['user']['role'];
                $_SESSION['user_name'] = $result['user']['full_name'];
                $_SESSION['user_email'] = $result['user']['email'];

                if ($result['user']['role'] === 'admin') {
                    $result['redirect'] = 'admin.html';
                } else {
                    $result['redirect'] = 'index.html';
                }
            }

            echo json_encode($result, JSON_UNESCAPED_UNICODE);
            break;

        case 'check':
            if (isset($_SESSION['user_id'])) {
                // Получаем актуальные данные из БД
                $userData = $userModel->getById($_SESSION['user_id']);
                
                if ($userData) {
                    // Обновляем данные в сессии
                    $_SESSION['user_name'] = $userData['full_name'];
                    $_SESSION['user_email'] = $userData['email'];
                    $_SESSION['user_role'] = $userData['role'];
                    
                    echo json_encode([
                        'success' => true,
                        'data' => [
                            'authenticated' => true,
                            'user' => $userData
                        ]
                    ], JSON_UNESCAPED_UNICODE);
                } else {
                    // Пользователь не найден в БД
                    session_destroy();
                    echo json_encode([
                        'success' => true,
                        'data' => [
                            'authenticated' => false
                        ]
                    ], JSON_UNESCAPED_UNICODE);
                }
            } else {
                echo json_encode([
                    'success' => true,
                    'data' => [
                        'authenticated' => false
                    ]
                ], JSON_UNESCAPED_UNICODE);
            }
            break;

        case 'logout':
            session_destroy();
            echo json_encode([
                'success' => true,
                'message' => 'Выход выполнен'
            ], JSON_UNESCAPED_UNICODE);
            break;

        default:
            throw new Exception('Неизвестное действие');
    }

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>

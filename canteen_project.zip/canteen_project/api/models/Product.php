<?php
class Product {
    private $conn;
    private $table = 'products';

    public function __construct($db) {
        $this->conn = $db;
    }

    // Получить все товары
    public function getAll($limit = 50) {
        $query = "SELECT p.*, c.name as category_name, c.slug as category_slug,
                  (SELECT AVG(rating) FROM reviews WHERE product_id = p.id AND is_approved = 1) as avg_rating,
                  (SELECT COUNT(*) FROM reviews WHERE product_id = p.id AND is_approved = 1) as review_count
                  FROM " . $this->table . " p
                  LEFT JOIN categories c ON p.category_id = c.id
                  WHERE p.is_active = 1
                  ORDER BY p.created_at DESC
                  LIMIT :limit";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    // Получить товары по категории
    public function getByCategory($categorySlug, $limit = 50) {
        $query = "SELECT p.*, c.name as category_name, c.slug as category_slug,
                  (SELECT AVG(rating) FROM reviews WHERE product_id = p.id AND is_approved = 1) as avg_rating,
                  (SELECT COUNT(*) FROM reviews WHERE product_id = p.id AND is_approved = 1) as review_count
                  FROM " . $this->table . " p
                  LEFT JOIN categories c ON p.category_id = c.id
                  WHERE p.is_active = 1 AND c.slug = :slug
                  ORDER BY p.created_at DESC
                  LIMIT :limit";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':slug', $categorySlug);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    // Получить популярные товары
    public function getPopular($limit = 8) {
        $query = "SELECT p.*, c.name as category_name, c.slug as category_slug,
                  (SELECT AVG(rating) FROM reviews WHERE product_id = p.id AND is_approved = 1) as avg_rating,
                  (SELECT COUNT(*) FROM reviews WHERE product_id = p.id AND is_approved = 1) as review_count
                  FROM " . $this->table . " p
                  LEFT JOIN categories c ON p.category_id = c.id
                  WHERE p.is_active = 1 AND p.is_popular = 1
                  ORDER BY p.views_count DESC
                  LIMIT :limit";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    // Получить товары со скидкой
    public function getDiscount($limit = 8) {
        $query = "SELECT p.*, c.name as category_name, c.slug as category_slug,
                  (SELECT AVG(rating) FROM reviews WHERE product_id = p.id AND is_approved = 1) as avg_rating,
                  (SELECT COUNT(*) FROM reviews WHERE product_id = p.id AND is_approved = 1) as review_count
                  FROM " . $this->table . " p
                  LEFT JOIN categories c ON p.category_id = c.id
                  WHERE p.is_active = 1 AND p.is_discount = 1 AND p.old_price IS NOT NULL
                  ORDER BY ((p.old_price - p.price) / p.old_price) DESC
                  LIMIT :limit";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    // Поиск товаров
    public function search($searchTerm, $limit = 50) {
        $query = "SELECT p.*, c.name as category_name, c.slug as category_slug,
                  (SELECT AVG(rating) FROM reviews WHERE product_id = p.id AND is_approved = 1) as avg_rating,
                  (SELECT COUNT(*) FROM reviews WHERE product_id = p.id AND is_approved = 1) as review_count
                  FROM " . $this->table . " p
                  LEFT JOIN categories c ON p.category_id = c.id
                  WHERE p.is_active = 1 AND (p.name LIKE :search OR p.description LIKE :search)
                  ORDER BY p.name
                  LIMIT :limit";

        $searchParam = '%' . $searchTerm . '%';
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':search', $searchParam);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    // Получить товар по ID
    public function getById($id) {
        $query = "SELECT p.*, c.name as category_name, c.slug as category_slug,
                  (SELECT AVG(rating) FROM reviews WHERE product_id = p.id AND is_approved = 1) as avg_rating,
                  (SELECT COUNT(*) FROM reviews WHERE product_id = p.id AND is_approved = 1) as review_count
                  FROM " . $this->table . " p
                  LEFT JOIN categories c ON p.category_id = c.id
                  WHERE p.id = :id
                  LIMIT 1";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();

        $product = $stmt->fetch();

        if ($product) {
            // Увеличиваем счетчик просмотров
            $updateQuery = "UPDATE " . $this->table . " SET views_count = views_count + 1 WHERE id = :id";
            $updateStmt = $this->conn->prepare($updateQuery);
            $updateStmt->bindParam(':id', $id, PDO::PARAM_INT);
            $updateStmt->execute();
        }

        return $product;
    }

    // Получить отзывы товара
    public function getReviews($productId) {
        $query = "SELECT r.*, u.full_name as user_name
                  FROM reviews r
                  JOIN users u ON r.user_id = u.id
                  WHERE r.product_id = :product_id AND r.is_approved = 1
                  ORDER BY r.created_at DESC";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':product_id', $productId, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll();
    }
}
?>

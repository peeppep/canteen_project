<?php
class Order {
    private $conn;
    private $table = 'orders';
    private $itemsTable = 'order_items';

    public function __construct($db) {
        $this->conn = $db;
    }

    // Создание заказа
    public function create($userId, $orderData) {
        try {
            $this->conn->beginTransaction();

            // Генерация номера заказа
            $orderNumber = 'ORD-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -6));

            // Вставка заказа
            $query = "INSERT INTO " . $this->table . " 
                      (user_id, order_number, total_amount, delivery_type, delivery_address, comment, payment_method, status) 
                      VALUES (:user_id, :order_number, :total_amount, :delivery_type, :delivery_address, :comment, :payment_method, 'new')";

            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':user_id', $userId);
            $stmt->bindParam(':order_number', $orderNumber);
            $stmt->bindParam(':total_amount', $orderData['total_amount']);
            $stmt->bindParam(':delivery_type', $orderData['delivery_type']);
            $stmt->bindParam(':delivery_address', $orderData['delivery_address']);
            $stmt->bindParam(':comment', $orderData['comment']);
            $stmt->bindParam(':payment_method', $orderData['payment_method']);

            if (!$stmt->execute()) {
                throw new Exception('Ошибка создания заказа');
            }

            $orderId = $this->conn->lastInsertId();

            // Проверяем структуру таблицы order_items
            $checkQuery = "SHOW COLUMNS FROM " . $this->itemsTable . " LIKE 'price'";
            $checkStmt = $this->conn->query($checkQuery);
            $hasPrice = $checkStmt->rowCount() > 0;

            // Вставка товаров заказа
            if ($hasPrice) {
                $itemQuery = "INSERT INTO " . $this->itemsTable . " 
                              (order_id, product_id, quantity, price) 
                              VALUES (:order_id, :product_id, :quantity, :price)";
            } else {
                // Если колонки price нет, не используем её
                $itemQuery = "INSERT INTO " . $this->itemsTable . " 
                              (order_id, product_id, quantity) 
                              VALUES (:order_id, :product_id, :quantity)";
            }

            $itemStmt = $this->conn->prepare($itemQuery);

            foreach ($orderData['items'] as $item) {
                $itemStmt->bindParam(':order_id', $orderId);
                $itemStmt->bindParam(':product_id', $item['product_id']);
                $itemStmt->bindParam(':quantity', $item['quantity']);
                
                if ($hasPrice) {
                    $itemStmt->bindParam(':price', $item['price']);
                }

                if (!$itemStmt->execute()) {
                    throw new Exception('Ошибка добавления товара в заказ');
                }
            }

            $this->conn->commit();

            return [
                'success' => true,
                'order_id' => $orderId,
                'order_number' => $orderNumber
            ];

        } catch (Exception $e) {
            $this->conn->rollBack();
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }

    // Получить заказы пользователя
    public function getUserOrders($userId, $limit = 50) {
        $query = "SELECT o.*, 
                  (SELECT COUNT(*) FROM " . $this->itemsTable . " WHERE order_id = o.id) as items_count
                  FROM " . $this->table . " o
                  WHERE o.user_id = :user_id
                  ORDER BY o.created_at DESC
                  LIMIT :limit";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    // Получить все заказы (для админа)
    public function getAllOrders($filters = []) {
        $query = "SELECT o.*, u.full_name, u.email,
                  (SELECT COUNT(*) FROM " . $this->itemsTable . " WHERE order_id = o.id) as items_count
                  FROM " . $this->table . " o
                  LEFT JOIN users u ON o.user_id = u.id
                  WHERE 1=1";

        if (!empty($filters['status'])) {
            $query .= " AND o.status = :status";
        }

        if (!empty($filters['date_from'])) {
            $query .= " AND DATE(o.created_at) >= :date_from";
        }

        if (!empty($filters['date_to'])) {
            $query .= " AND DATE(o.created_at) <= :date_to";
        }

        $query .= " ORDER BY o.created_at DESC LIMIT 100";

        $stmt = $this->conn->prepare($query);

        if (!empty($filters['status'])) {
            $stmt->bindParam(':status', $filters['status']);
        }

        if (!empty($filters['date_from'])) {
            $stmt->bindParam(':date_from', $filters['date_from']);
        }

        if (!empty($filters['date_to'])) {
            $stmt->bindParam(':date_to', $filters['date_to']);
        }

        $stmt->execute();

        return $stmt->fetchAll();
    }

    // Получить заказ по ID
    public function getById($orderId, $userId = null) {
        $query = "SELECT o.*, u.full_name, u.email, u.phone
                  FROM " . $this->table . " o
                  LEFT JOIN users u ON o.user_id = u.id
                  WHERE o.id = :order_id";

        if ($userId !== null) {
            $query .= " AND o.user_id = :user_id";
        }

        $query .= " LIMIT 1";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':order_id', $orderId);

        if ($userId !== null) {
            $stmt->bindParam(':user_id', $userId);
        }

        $stmt->execute();

        $order = $stmt->fetch();

        if ($order) {
            // Получаем товары заказа
            $itemsQuery = "SELECT oi.*, p.name, p.image_path, p.price as current_price
                          FROM " . $this->itemsTable . " oi
                          LEFT JOIN products p ON oi.product_id = p.id
                          WHERE oi.order_id = :order_id";

            $itemsStmt = $this->conn->prepare($itemsQuery);
            $itemsStmt->bindParam(':order_id', $orderId);
            $itemsStmt->execute();

            $order['items'] = $itemsStmt->fetchAll();
        }

        return $order;
    }

    // Статистика заказов
    public function getStatistics($userId = null) {
        $query = "SELECT 
                  COUNT(*) as total,
                  SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
                  COALESCE(SUM(total_amount), 0) as total_amount,
                  COALESCE(AVG(total_amount), 0) as avg_amount
                  FROM " . $this->table;

        if ($userId !== null) {
            $query .= " WHERE user_id = :user_id";
        }

        $stmt = $this->conn->prepare($query);

        if ($userId !== null) {
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        }

        $stmt->execute();

        return $stmt->fetch();
    }

    // Обновление статуса заказа
    public function updateStatus($orderId, $status) {
        $query = "UPDATE " . $this->table . " SET status = :status, updated_at = CURRENT_TIMESTAMP WHERE id = :order_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':order_id', $orderId);
        return $stmt->execute();
    }

    // Отмена заказа
    public function cancel($orderId, $userId = null) {
        $query = "UPDATE " . $this->table . " SET status = 'cancelled', updated_at = CURRENT_TIMESTAMP WHERE id = :order_id";
        
        if ($userId !== null) {
            $query .= " AND user_id = :user_id";
        }
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':order_id', $orderId);
        
        if ($userId !== null) {
            $stmt->bindParam(':user_id', $userId);
        }
        
        if ($stmt->execute()) {
            return [
                'success' => true,
                'message' => 'Заказ отменен'
            ];
        }
        
        return [
            'success' => false,
            'message' => 'Ошибка отмены заказа'
        ];
    }
}
?>

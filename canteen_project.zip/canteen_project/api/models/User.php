<?php
class User {
    private $conn;
    private $table = 'users';

    public function __construct($db) {
        $this->conn = $db;
    }

    // Регистрация пользователя
    public function register($fullName, $email, $password) {
        // Проверка существования email
        $query = "SELECT id FROM " . $this->table . " WHERE email = :email";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':email', $email);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            return [
                'success' => false,
                'message' => 'Пользователь с таким email уже существует'
            ];
        }

        // Хеширование пароля
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Вставка пользователя
        $query = "INSERT INTO " . $this->table . " (full_name, email, password, role, is_active, email_verified) 
                  VALUES (:full_name, :email, :password, 'user', 1, 0)";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':full_name', $fullName);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':password', $hashedPassword);

        if ($stmt->execute()) {
            return [
                'success' => true,
                'message' => 'Регистрация успешна'
            ];
        }

        return [
            'success' => false,
            'message' => 'Ошибка при регистрации'
        ];
    }

    // Вход пользователя
    public function login($email, $password) {
        $query = "SELECT * FROM " . $this->table . " WHERE email = :email LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':email', $email);
        $stmt->execute();

        if ($stmt->rowCount() === 0) {
            return [
                'success' => false,
                'message' => 'Неверный email или пароль'
            ];
        }

        $user = $stmt->fetch();

        if (!$user['is_active']) {
            return [
                'success' => false,
                'message' => 'Аккаунт заблокирован'
            ];
        }

        if (!password_verify($password, $user['password'])) {
            return [
                'success' => false,
                'message' => 'Неверный email или пароль'
            ];
        }

        // Обновляем время последнего входа
        $updateQuery = "UPDATE " . $this->table . " SET last_login = CURRENT_TIMESTAMP WHERE id = :id";
        $updateStmt = $this->conn->prepare($updateQuery);
        $updateStmt->bindParam(':id', $user['id']);
        $updateStmt->execute();

        unset($user['password']);

        return [
            'success' => true,
            'user' => $user
        ];
    }

    // Получить всех пользователей (для админа)
    public function getAll($search = '', $role = '', $limit = 100) {
        $query = "SELECT id, full_name, email, phone, role, is_active, email_verified, created_at, last_login 
                  FROM " . $this->table . " WHERE 1=1";

        if (!empty($search)) {
            $query .= " AND (full_name LIKE :search OR email LIKE :search)";
        }

        if (!empty($role)) {
            $query .= " AND role = :role";
        }

        $query .= " ORDER BY created_at DESC LIMIT :limit";

        $stmt = $this->conn->prepare($query);

        if (!empty($search)) {
            $searchParam = '%' . $search . '%';
            $stmt->bindParam(':search', $searchParam);
        }

        if (!empty($role)) {
            $stmt->bindParam(':role', $role);
        }

        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    // Получить пользователя по ID
    public function getById($id) {
        $query = "SELECT id, full_name, email, phone, role, is_active, email_verified, created_at, last_login, avatar
                  FROM " . $this->table . " WHERE id = :id LIMIT 1";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetch();
    }

    // Создание пользователя админом
    public function createByAdmin($fullName, $email, $password, $role, $phone) {
        // Проверка существования email
        $query = "SELECT id FROM " . $this->table . " WHERE email = :email";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':email', $email);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            return [
                'success' => false,
                'message' => 'Пользователь с таким email уже существует'
            ];
        }

        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $query = "INSERT INTO " . $this->table . " (full_name, email, password, phone, role, is_active, email_verified) 
                  VALUES (:full_name, :email, :password, :phone, :role, 1, 1)";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':full_name', $fullName);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':password', $hashedPassword);
        $stmt->bindParam(':phone', $phone);
        $stmt->bindParam(':role', $role);

        if ($stmt->execute()) {
            return [
                'success' => true,
                'user_id' => $this->conn->lastInsertId()
            ];
        }

        return [
            'success' => false,
            'message' => 'Ошибка при создании пользователя'
        ];
    }

    // Обновление пользователя
    public function update($id, $data) {
        $fields = [];
        $params = [':id' => $id];

        // Проверяем и добавляем только непустые поля
        if (isset($data['full_name']) && !empty($data['full_name'])) {
            $fields[] = "full_name = :full_name";
            $params[':full_name'] = $data['full_name'];
        }

        if (isset($data['email']) && !empty($data['email'])) {
            // Проверка уникальности email
            $checkQuery = "SELECT id FROM " . $this->table . " WHERE email = :email AND id != :id";
            $checkStmt = $this->conn->prepare($checkQuery);
            $checkStmt->bindParam(':email', $data['email']);
            $checkStmt->bindParam(':id', $id);
            $checkStmt->execute();

            if ($checkStmt->rowCount() > 0) {
                throw new Exception('Пользователь с таким email уже существует');
            }

            $fields[] = "email = :email";
            $params[':email'] = $data['email'];
        }

        if (isset($data['phone'])) {
            $fields[] = "phone = :phone";
            $params[':phone'] = $data['phone'];
        }

        if (isset($data['password']) && !empty($data['password'])) {
            $fields[] = "password = :password";
            $params[':password'] = $data['password'];
        }

        if (isset($data['role']) && !empty($data['role'])) {
            $fields[] = "role = :role";
            $params[':role'] = $data['role'];
        }

        if (isset($data['is_active'])) {
            $fields[] = "is_active = :is_active";
            $params[':is_active'] = (int)$data['is_active'];
        }

        if (empty($fields)) {
            return true; // Нечего обновлять
        }

        $fields[] = "updated_at = CURRENT_TIMESTAMP";

        $query = "UPDATE " . $this->table . " SET " . implode(', ', $fields) . " WHERE id = :id";

        $stmt = $this->conn->prepare($query);

        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }

        return $stmt->execute();
    }

    // Удаление пользователя
    public function delete($id) {
        $query = "DELETE FROM " . $this->table . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        return $stmt->execute();
    }

    // Изменение статуса активности
    public function toggleStatus($id, $isActive) {
        $query = "UPDATE " . $this->table . " SET is_active = :is_active, updated_at = CURRENT_TIMESTAMP WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':is_active', $isActive, PDO::PARAM_INT);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        return $stmt->execute();
    }
}
?>

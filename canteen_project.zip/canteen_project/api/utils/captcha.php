<?php
session_start();

// Генерация кода
$code = strtoupper(substr(md5(rand()), 0, 4));
$_SESSION['captcha_code'] = $code;

// Создаем SVG
$width = 140;
$height = 50;

header('Content-Type: image/svg+xml');
header('Cache-Control: no-cache');

// Случайные параметры для усложнения
$rotation = rand(-10, 10);
$fontSize = rand(20, 24);
$letterSpacing = rand(8, 12);

echo '<?xml version="1.0" encoding="UTF-8"?>';
?>
<svg width="<?php echo $width; ?>" height="<?php echo $height; ?>" xmlns="http://www.w3.org/2000/svg">
    <!-- Фон -->
    <rect width="<?php echo $width; ?>" height="<?php echo $height; ?>" fill="#2E2E2E"/>
    
    <!-- Линии помех -->
    <?php for ($i = 0; $i < 5; $i++): ?>
        <line x1="<?php echo rand(0, $width); ?>" 
              y1="<?php echo rand(0, $height); ?>" 
              x2="<?php echo rand(0, $width); ?>" 
              y2="<?php echo rand(0, $height); ?>" 
              stroke="#3E3E3E" 
              stroke-width="1"/>
    <?php endfor; ?>
    
    <!-- Точки помех -->
    <?php for ($i = 0; $i < 50; $i++): ?>
        <circle cx="<?php echo rand(0, $width); ?>" 
                cy="<?php echo rand(0, $height); ?>" 
                r="1" 
                fill="#3E3E3E"/>
    <?php endfor; ?>
    
    <!-- Текст капчи -->
    <text x="50%" 
          y="50%" 
          dominant-baseline="middle" 
          text-anchor="middle" 
          font-family="Arial, sans-serif" 
          font-size="<?php echo $fontSize; ?>" 
          font-weight="bold" 
          fill="#89FF62"
          letter-spacing="<?php echo $letterSpacing; ?>"
          transform="rotate(<?php echo $rotation; ?>, <?php echo $width/2; ?>, <?php echo $height/2; ?>)">
        <?php echo $code; ?>
    </text>
    
    <!-- Дополнительные линии поверх текста -->
    <?php for ($i = 0; $i < 3; $i++): ?>
        <line x1="<?php echo rand(0, $width); ?>" 
              y1="<?php echo rand(0, $height); ?>" 
              x2="<?php echo rand(0, $width); ?>" 
              y2="<?php echo rand(0, $height); ?>" 
              stroke="#3E3E3E" 
              stroke-width="2" 
              opacity="0.5"/>
    <?php endfor; ?>
</svg>

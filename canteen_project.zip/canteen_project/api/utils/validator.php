<?php
class Validator {
    public static function email($email) {
        return filter_var($email, FILTER_VALIDATE_EMAIL);
    }

    public static function minLength($string, $min) {
        return mb_strlen($string) >= $min;
    }

    public static function maxLength($string, $max) {
        return mb_strlen($string) <= $max;
    }

    public static function required($value) {
        return !empty(trim($value));
    }

    public static function phone($phone) {
        return preg_match('/^[0-9]{10,15}$/', preg_replace('/\D/', '', $phone));
    }

    public static function price($price) {
        return is_numeric($price) && $price >= 0;
    }

    public static function sanitize($string) {
        return htmlspecialchars(strip_tags(trim($string)), ENT_QUOTES, 'UTF-8');
    }
}
?>

<?php
function validateCaptcha($input) {
    return isset($_SESSION['captcha_code']) && 
           strtoupper($input) === strtoupper($_SESSION['captcha_code']);
}
?>

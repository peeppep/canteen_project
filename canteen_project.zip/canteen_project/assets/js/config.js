// Конфигурация путей проекта
const BASE_PATH = '/canteen_project/';
const API_BASE_URL = BASE_PATH + 'api/controllers/';

// Вспомогательные функции для путей
function getApiUrl(controller, params = '') {
    return API_BASE_URL + controller + (params ? '?' + params : '');
}

function getImageUrl(imagePath) {
    return BASE_PATH + 'assets/images/products/' + imagePath;
}
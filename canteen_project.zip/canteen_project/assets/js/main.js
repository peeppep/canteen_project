// Главная страница - загрузка товаров

let currentCategory = 'all';

// Загрузка товаров со скидками
async function loadDiscountProducts() {
    try {
        const response = await fetch(getApiUrl('ProductController.php', 'action=list&discount=1'));

        const contentType = response.headers.get("content-type");
        if (!contentType || !contentType.includes("application/json")) {
            console.error('API returned non-JSON response');
            document.getElementById('discountSection').style.display = 'none';
            return;
        }

        const result = await response.json();

        if (result.success && result.data && result.data.length > 0) {
            renderProductsHorizontal(result.data, 'discountProducts');
        } else {
            document.getElementById('discountSection').style.display = 'none';
        }
    } catch (error) {
        console.error('Error loading discount products:', error);
        document.getElementById('discountSection').style.display = 'none';
    }
}

// Загрузка популярных товаров
async function loadPopularProducts() {
    try {
        const response = await fetch(getApiUrl('ProductController.php', 'action=list&popular=1'));

        const contentType = response.headers.get("content-type");
        if (!contentType || !contentType.includes("application/json")) {
            console.error('API returned non-JSON response');
            return;
        }

        const result = await response.json();

        if (result.success && result.data && result.data.length > 0) {
            renderProductsHorizontal(result.data, 'popularProducts');
        }
    } catch (error) {
        console.error('Error loading popular products:', error);
    }
}

// Загрузка каталога
async function loadCatalog(category = 'all') {
    const container = document.getElementById('catalogProducts');
    container.innerHTML = '<div class="loader" style="grid-column: 1/-1;"></div>';

    try {
        const params = category !== 'all' ? `action=list&category=${category}` : 'action=list';
        const response = await fetch(getApiUrl('ProductController.php', params));

        const contentType = response.headers.get("content-type");
        if (!contentType || !contentType.includes("application/json")) {
            console.error('API returned non-JSON response');
            container.innerHTML = '<p style="color: var(--text-gray); grid-column: 1/-1; text-align: center; padding: 40px;">Ошибка загрузки товаров. Проверьте API.</p>';
            return;
        }

        const result = await response.json();

        if (result.success && result.data) {
            renderProductsGrid(result.data, 'catalogProducts');
        } else {
            container.innerHTML = '<p style="color: var(--text-gray); grid-column: 1/-1; text-align: center; padding: 40px;">Товары не найдены</p>';
        }
    } catch (error) {
        console.error('Error loading catalog:', error);
        container.innerHTML = '<p style="color: var(--text-gray); grid-column: 1/-1; text-align: center; padding: 40px;">Ошибка соединения с сервером</p>';
    }
}

// Рендер товаров (горизонтальный скролл)
function renderProductsHorizontal(products, containerId) {
    const container = document.getElementById(containerId);

    if (!container) {
        console.error('Container not found:', containerId);
        return;
    }

    if (!products || products.length === 0) {
        container.innerHTML = '<p style="color: var(--text-gray);">Товары не найдены</p>';
        return;
    }

    container.innerHTML = products.slice(0, 8).map(product => createProductCard(product)).join('');
}

// Рендер товаров (сетка)
function renderProductsGrid(products, containerId) {
    const container = document.getElementById(containerId);

    if (!container) {
        console.error('Container not found:', containerId);
        return;
    }

    if (!products || products.length === 0) {
        container.innerHTML = '<p style="color: var(--text-gray); grid-column: 1/-1; text-align: center; padding: 40px;">Товары не найдены</p>';
        return;
    }

    container.innerHTML = products.map(product => createProductCard(product)).join('');
}

// Создание карточки товара
function createProductCard(product) {
    const avgRating = product.avg_rating ? parseFloat(product.avg_rating).toFixed(1) : '0.0';
    const imagePath = product.image_path ? getImageUrl(product.image_path) : getImageUrl('default.jpg');
    const weight = `${product.weight}${product.unit === 'g' ? 'г' : product.unit === 'ml' ? 'мл' : 'шт'}`;
    const safeName = (product.name || '').replace(/'/g, "\\'");

    return `
        <div class="product-card" onclick="window.location.href='${BASE_PATH}product.html?id=${product.id}'">
            <div class="product-image-wrapper">
                <img src="${imagePath}" alt="${product.name}" onerror="this.src='${getImageUrl('default.jpg')}'" loading="lazy">
                <div class="weight-badge">${weight}</div>
                <button class="add-to-cart-btn" onclick="event.stopPropagation(); handleAddToCart(this, ${product.id}, '${safeName}', ${product.price}, '${weight}', '${product.image_path || ''}')">
                    +
                </button>
            </div>
            <div class="product-name">${product.name}</div>
            <div class="product-footer">
                <div>
                    <span class="product-price">${product.price}₽</span>
                    ${product.old_price ? `<span class="old-price">${product.old_price}₽</span>` : ''}
                </div>
                <div class="product-rating">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                        <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
                    </svg>
                    <span>${avgRating}</span>
                </div>
            </div>
        </div>
    `;
}

// Обработка добавления в корзину
function handleAddToCart(btn, id, name, price, weight, image) {
    addToCart(id, name, price, 1, weight, image);
    btn.classList.add('added');
    btn.textContent = '✓';
    
    setTimeout(() => {
        btn.classList.remove('added');
        btn.textContent = '+';
    }, 1500);
}

// Фильтрация по категориям
function filterCatalog(category, btn) {
    currentCategory = category;
    
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    
    loadCatalog(category);
}

// Поиск
const searchInput = document.getElementById('searchInput');
if (searchInput) {
    let searchTimeout;
    searchInput.addEventListener('input', (e) => {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            const query = e.target.value.trim();
            if (query.length > 2) {
                searchProducts(query);
            } else if (query.length === 0) {
                loadCatalog(currentCategory);
            }
        }, 500);
    });
}

// Поиск товаров
async function searchProducts(query) {
    const container = document.getElementById('catalogProducts');
    container.innerHTML = '<div class="loader" style="grid-column: 1/-1;"></div>';
    
    try {
        const response = await fetch(getApiUrl('ProductController.php', `action=list&search=${encodeURIComponent(query)}`));
        const result = await response.json();
        
        if (result.success) {
            renderProductsGrid(result.data, 'catalogProducts');
        }
    } catch (error) {
        console.error('Error searching products:', error);
        container.innerHTML = '<p style="color: var(--text-gray); grid-column: 1/-1; text-align: center;">Ошибка поиска</p>';
    }
}

// Инициализация фильтров
document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
        const category = e.target.dataset.category;
        filterCatalog(category, e.target);
    });
});

// Проверка авторизации
async function checkAuthStatus() {
    try {
        const response = await fetch(getApiUrl('AuthController.php', 'action=check'));
        const result = await response.json();
        
        if (result.data && result.data.authenticated) {
            const profileText = document.getElementById('profileText');
            if (profileText && result.data.user) {
                profileText.textContent = result.data.user.name.split(' ')[0];
            }
        }
    } catch (error) {
        console.log('User not authenticated');
    }
}

// Загрузка данных при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
    console.log('Page loaded, starting to load products...');
    
    loadDiscountProducts();
    loadPopularProducts();
    loadCatalog();
    checkAuthStatus();
    updateCartBadge();
});
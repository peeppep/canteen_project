// Проверка прав администратора
async function checkAdminAccess() {
    const user = await checkAuth();

    if (!user || user.role !== 'admin') {
        alert('Доступ запрещен. Только для администраторов.');
        window.location.href = 'index.html';
        return false;
    }

    return true;
}

// Обновление времени
function updateTime() {
    const now = new Date();
    const timeStr = now.toLocaleString('ru-RU', {
        hour: '2-digit',
        minute: '2-digit',
        day: '2-digit',
        month: '2-digit'
    });
    const timeElement = document.getElementById('currentTime');
    if (timeElement) {
        timeElement.textContent = timeStr;
    }
}

setInterval(updateTime, 1000);
updateTime();

// Переключение секций
function switchSection(section) {
    document.querySelectorAll('.admin-menu-item').forEach(item => item.classList.remove('active'));
    event.currentTarget.classList.add('active');

    switch (section) {
        case 'dashboard':
            loadDashboard();
            break;
        case 'products':
            loadProducts();
            break;
        case 'orders':
            loadOrders();
            break;
        case 'users':
            loadUsers();
            break;
    }
}

// Загрузка дашборда
async function loadDashboard() {
    try {
        const response = await fetch('api/controllers/AdminController.php?resource=stats&action=get');
        const result = await response.json();

        if (result.success) {
            renderDashboard(result.data);
        }
    } catch (error) {
        console.error('Error:', error);
    }
}

function renderDashboard(stats) {
    const content = document.getElementById('adminContent');

    content.innerHTML = `
        <div style="margin-bottom: 30px;">
            <h1 style="font-size: 36px; margin-bottom: 10px;">Панель управления</h1>
            <p style="color: var(--text-gray);">Добро пожаловать в админ-панель столовой</p>
        </div>

        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                        <circle cx="9" cy="7" r="4"></circle>
                        <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                        <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                    </svg>
                </div>
                <div class="stat-value">${stats.users_count}</div>
                <div class="stat-label">Пользователей</div>
            </div>

            <div class="stat-card">
                <div class="stat-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"></path>
                        <rect x="8" y="2" width="8" height="4" rx="1" ry="1"></rect>
                    </svg>
                </div>
                <div class="stat-value">${stats.orders_count}</div>
                <div class="stat-label">Заказов</div>
            </div>

            <div class="stat-card">
                <div class="stat-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="12" y1="1" x2="12" y2="23"></line>
                        <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                    </svg>
                </div>
                <div class="stat-value">${parseFloat(stats.total_revenue).toFixed(0)}₽</div>
                <div class="stat-label">Выручка</div>
            </div>

            <div class="stat-card">
                <div class="stat-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
                        <line x1="3" y1="6" x2="21" y2="6"></line>
                        <path d="M16 10a4 4 0 0 1-8 0"></path>
                    </svg>
                </div>
                <div class="stat-value">${stats.products_count}</div>
                <div class="stat-label">Товаров</div>
            </div>
        </div>

        <div style="margin-top: 40px;">
            <h2 style="font-size: 24px; margin-bottom: 20px;">Последние заказы</h2>
            ${stats.recent_orders && stats.recent_orders.length > 0 ? `
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Номер</th>
                            <th>Клиент</th>
                            <th>Сумма</th>
                            <th>Статус</th>
                            <th>Дата</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${stats.recent_orders.map(order => `
                            <tr>
                                <td><strong>${order.order_number}</strong></td>
                                <td>${order.full_name}</td>
                                <td>${parseFloat(order.total_amount).toFixed(2)} ₽</td>
                                <td><span class="badge badge-${order.status === 'completed' ? 'active' : 'inactive'}">${order.status}</span></td>
                                <td>${new Date(order.created_at).toLocaleDateString('ru-RU')}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            ` : '<p style="color: var(--text-gray);">Заказов пока нет</p>'}
        </div>
    `;
}

// Загрузка товаров
async function loadProducts() {
    try {
        const response = await fetch('api/controllers/ProductController.php?action=list');
        const result = await response.json();

        if (result.success) {
            renderProducts(result.data);
        }
    } catch (error) {
        console.error('Error:', error);
    }
}

function renderProducts(products) {
    const content = document.getElementById('adminContent');
    
    content.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
            <div>
                <h1 style="font-size: 36px; margin-bottom: 5px;">Управление товарами</h1>
                <p style="color: var(--text-gray);">Всего товаров: ${products.length}</p>
            </div>
            <button class="btn btn-primary" onclick="openProductModal()">+ Добавить товар</button>
        </div>

        <table class="data-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Название</th>
                    <th>Категория</th>
                    <th>Цена</th>
                    <th>Вес</th>
                    <th>Статус</th>
                    <th>Действия</th>
                </tr>
            </thead>
            <tbody>
                ${products.map(product => `
                    <tr>
                        <td>${product.id}</td>
                        <td><strong>${product.name}</strong></td>
                        <td>${product.category_name}</td>
                        <td>${product.price} ₽</td>
                        <td>${product.weight}${product.unit === 'g' ? 'г' : product.unit === 'ml' ? 'мл' : 'шт'}</td>
                        <td><span class="badge badge-${product.is_active ? 'active' : 'inactive'}">${product.is_active ? 'Активен' : 'Неактивен'}</span></td>
                        <td>
                            <button class="action-btn btn-edit" onclick="editProduct(${product.id})">Изменить</button>
                            <button class="action-btn btn-delete" onclick="deleteProduct(${product.id})">Удалить</button>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

// Загрузка заказов
async function loadOrders() {
    try {
        const response = await fetch('api/controllers/AdminController.php?resource=orders&action=list');
        const result = await response.json();

        if (result.success) {
            renderOrders(result.data);
        }
    } catch (error) {
        console.error('Error:', error);
    }
}

function renderOrders(orders) {
    const content = document.getElementById('adminContent');
    
    content.innerHTML = `
        <div style="margin-bottom: 30px;">
            <h1 style="font-size: 36px; margin-bottom: 5px;">Управление заказами</h1>
            <p style="color: var(--text-gray);">Всего заказов: ${orders.length}</p>
        </div>

        <table class="data-table">
            <thead>
                <tr>
                    <th>Номер</th>
                    <th>Клиент</th>
                    <th>Email</th>
                    <th>Сумма</th>
                    <th>Статус</th>
                    <th>Дата</th>
                    <th>Действия</th>
                </tr>
            </thead>
            <tbody>
                ${orders.map(order => `
                    <tr>
                        <td><strong>${order.order_number}</strong></td>
                        <td>${order.full_name}</td>
                        <td>${order.email}</td>
                        <td>${parseFloat(order.total_amount).toFixed(2)} ₽</td>
                        <td>
                            <select class="form-input" style="padding: 8px; font-size: 13px;" onchange="updateOrderStatus(${order.id}, this.value)">
                                <option value="new" ${order.status === 'new' ? 'selected' : ''}>Новый</option>
                                <option value="confirmed" ${order.status === 'confirmed' ? 'selected' : ''}>Подтвержден</option>
                                <option value="preparing" ${order.status === 'preparing' ? 'selected' : ''}>Готовится</option>
                                <option value="ready" ${order.status === 'ready' ? 'selected' : ''}>Готов</option>
                                <option value="completed" ${order.status === 'completed' ? 'selected' : ''}>Выполнен</option>
                                <option value="cancelled" ${order.status === 'cancelled' ? 'selected' : ''}>Отменен</option>
                            </select>
                        </td>
                        <td>${new Date(order.created_at).toLocaleString('ru-RU')}</td>
                        <td>
                            <button class="action-btn btn-edit" onclick="alert('Просмотр деталей заказа')">Детали</button>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

// Обновление статуса заказа
async function updateOrderStatus(orderId, status) {
    try {
        const response = await fetch('api/controllers/AdminController.php?resource=orders&action=update_status', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: orderId, status: status })
        });

        const result = await response.json();
        
        if (result.success) {
            showNotification('Статус заказа обновлен');
        } else {
            alert('Ошибка: ' + result.message);
        }
    } catch (error) {
        console.error('Error:', error);
    }
}

// Загрузка пользователей
async function loadUsers() {
    try {
        const response = await fetch('api/controllers/AdminController.php?resource=users&action=list');
        const result = await response.json();

        if (result.success) {
            renderUsers(result.data);
        }
    } catch (error) {
        console.error('Error:', error);
    }
}

function renderUsers(users) {
    const content = document.getElementById('adminContent');
    
    content.innerHTML = `
        <div style="margin-bottom: 30px;">
            <h1 style="font-size: 36px; margin-bottom: 5px;">Управление пользователями</h1>
            <p style="color: var(--text-gray);">Всего пользователей: ${users.length}</p>
        </div>

        <table class="data-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Имя</th>
                    <th>Email</th>
                    <th>Роль</th>
                    <th>Статус</th>
                    <th>Регистрация</th>
                    <th>Последний вход</th>
                    <th>Действия</th>
                </tr>
            </thead>
            <tbody>
                ${users.map(user => `
                    <tr>
                        <td>${user.id}</td>
                        <td><strong>${user.full_name}</strong></td>
                        <td>${user.email}</td>
                        <td><span class="badge badge-${user.role === 'admin' ? 'admin' : 'active'}">${user.role === 'admin' ? 'Админ' : 'Пользователь'}</span></td>
                        <td><span class="badge badge-${user.is_active ? 'active' : 'inactive'}">${user.is_active ? 'Активен' : 'Заблокирован'}</span></td>
                        <td>${new Date(user.created_at).toLocaleDateString('ru-RU')}</td>
                        <td>${user.last_login ? new Date(user.last_login).toLocaleString('ru-RU') : 'Никогда'}</td>
                        <td>
                            ${user.role !== 'admin' ? `
                                <button class="action-btn btn-toggle" onclick="toggleUser(${user.id}, ${!user.is_active})">${user.is_active ? 'Заблокировать' : 'Разблокировать'}</button>
                                <button class="action-btn btn-delete" onclick="deleteUser(${user.id})">Удалить</button>
                            ` : '<span style="color: var(--text-gray);">Администратор</span>'}
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

// Управление пользователями
async function toggleUser(userId, isActive) {
    try {
        const response = await fetch('api/controllers/AdminController.php?resource=users&action=toggle', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: userId, is_active: isActive ? 1 : 0 })
        });

        const result = await response.json();
        
        if (result.success) {
            showNotification('Статус пользователя обновлен');
            loadUsers();
        }
    } catch (error) {
        console.error('Error:', error);
    }
}

async function deleteUser(userId) {
    if (!confirm('Вы уверены, что хотите удалить этого пользователя?')) return;

    try {
        const response = await fetch(`api/controllers/AdminController.php?resource=users&action=delete&id=${userId}`);
        const result = await response.json();
        
        if (result.success) {
            showNotification('Пользователь удален');
            loadUsers();
        }
    } catch (error) {
        console.error('Error:', error);
    }
}

// Модальное окно для товаров
function openProductModal(productId = null) {
    const modal = document.getElementById('productModal');
    const form = document.getElementById('productForm');
    
    form.reset();
    document.getElementById('modalTitle').textContent = productId ? 'Редактировать товар' : 'Добавить товар';
    
    if (productId) {
        // Загрузка данных товара для редактирования
        loadProductData(productId);
    }
    
    modal.classList.add('show');
}

function closeModal() {
    document.getElementById('productModal').classList.remove('show');
}

async function loadProductData(productId) {
    try {
        const response = await fetch(`api/controllers/ProductController.php?action=get&id=${productId}`);
        const result = await response.json();

        if (result.success) {
            const product = result.data;
            document.getElementById('productId').value = product.id;
            document.getElementById('productName').value = product.name;
            document.getElementById('productCategory').value = product.category_id;
            document.getElementById('productDescription').value = product.description || '';
            document.getElementById('productComposition').value = product.composition || '';
            document.getElementById('productPrice').value = product.price;
            document.getElementById('productOldPrice').value = product.old_price || '';
            document.getElementById('productWeight').value = product.weight;
            document.getElementById('productUnit').value = product.unit;
            document.getElementById('productPopular').checked = product.is_popular == 1;
            document.getElementById('productDiscount').checked = product.is_discount == 1;
            document.getElementById('productActive').checked = product.is_active == 1;
        }
    } catch (error) {
        console.error('Error:', error);
    }
}

function editProduct(productId) {
    openProductModal(productId);
}

async function deleteProduct(productId) {
    if (!confirm('Вы уверены, что хотите удалить этот товар?')) return;

    try {
        const response = await fetch(`api/controllers/AdminController.php?resource=products&action=delete&id=${productId}`);
        const result = await response.json();
        
        if (result.success) {
            showNotification('Товар удален');
            loadProducts();
        }
    } catch (error) {
        console.error('Error:', error);
    }
}

// Обработка формы товара
document.getElementById('productForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const data = {};
    
    formData.forEach((value, key) => {
        if (key === 'is_popular' || key === 'is_discount' || key === 'is_active') {
            data[key] = value === 'on' ? 1 : 0;
        } else {
            data[key] = value;
        }
    });
    
    // Если чекбоксы не отмечены, устанавливаем 0
    if (!data.is_popular) data.is_popular = 0;
    if (!data.is_discount) data.is_discount = 0;
    if (!data.is_active) data.is_active = 0;
    
    const isEdit = data.id && data.id !== '';
    const action = isEdit ? 'update' : 'create';
    
    try {
        const response = await fetch(`api/controllers/AdminController.php?resource=products&action=${action}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });

        const result = await response.json();
        
        if (result.success) {
            showNotification(isEdit ? 'Товар обновлен' : 'Товар добавлен');
            closeModal();
            loadProducts();
        } else {
            alert('Ошибка: ' + result.message);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Ошибка соединения с сервером');
    }
});

function showNotification(message) {
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: var(--accent-green);
        color: var(--bg-dark);
        padding: 15px 25px;
        border-radius: 15px;
        font-weight: 600;
        z-index: 10000;
        animation: slideIn 0.3s ease;
        box-shadow: 0 5px 20px rgba(137, 255, 98, 0.4);
    `;
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.style.animation = 'fadeOut 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 2000);
}

// Инициализация
checkAdminAccess().then(isAdmin => {
    if (isAdmin) {
        loadDashboard();
    }
});
// Обработка формы входа
const loginForm = document.getElementById('loginForm');

if (loginForm) {
    loginForm.addEventListener('submit', async(e) => {
        e.preventDefault();

        const formData = new FormData(e.target);
        const data = Object.fromEntries(formData);

        const submitBtn = e.target.querySelector('button[type="submit"]');
        const originalText = submitBtn.textContent;
        submitBtn.textContent = 'Вход...';
        submitBtn.disabled = true;

        try {
            const response = await fetch('api/controllers/AuthController.php?action=login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });

            const result = await response.json();
            const messageDiv = document.getElementById('message');

            if (result.success) {
                messageDiv.innerHTML = '<div class="success-message">Вход выполнен! Перенаправление...</div>';
                setTimeout(() => {
                    window.location.href = result.data.redirect;
                }, 1000);
            } else {
                messageDiv.innerHTML = '<div class="error-message">' + result.message + '</div>';
                submitBtn.textContent = originalText;
                submitBtn.disabled = false;
            }
        } catch (error) {
            console.error('Error:', error);
            document.getElementById('message').innerHTML = '<div class="error-message">Ошибка соединения с сервером</div>';
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
        }
    });
}

// Проверка авторизации
async function checkAuth() {
    try {
        const response = await fetch('api/controllers/AuthController.php?action=check');
        const result = await response.json();

        if (result.data.authenticated) {
            const profileBtn = document.getElementById('profileText');
            if (profileBtn) {
                profileBtn.textContent = result.data.user.name.split(' ')[0];
            }
            return result.data.user;
        }
        return null;
    } catch (error) {
        console.error('Error:', error);
        return null;
    }
}

// Выход
async function logout() {
    if (confirm('Вы уверены, что хотите выйти?')) {
        try {
            await fetch('api/controllers/AuthController.php?action=logout');
            window.location.href = 'index.html';
        } catch (error) {
            console.error('Error:', error);
        }
    }
}

// Проверка при загрузке страницы
if (window.location.pathname.includes('profile.html') || window.location.pathname.includes('admin.html')) {
    checkAuth().then(user => {
        if (!user) {
            window.location.href = 'login.html';
        }
    });
}
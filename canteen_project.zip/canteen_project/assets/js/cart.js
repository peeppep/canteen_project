// Управление корзиной
const CART_KEY = 'canteen_cart';

// Получить корзину
function getCart() {
    const cart = localStorage.getItem(CART_KEY);
    return cart ? JSON.parse(cart) : [];
}

// Сохранить корзину
function saveCart(cart) {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
    updateCartBadge();
}

// Добавить товар
function addToCart(id, name, price, quantity = 1, weight = '500г', image = '') {
    let cart = getCart();
    const existingItem = cart.find(item => item.id === id);

    if (existingItem) {
        existingItem.quantity += quantity;
    } else {
        cart.push({ id, name, price, quantity, weight, image });
    }

    saveCart(cart);
    showNotification(`${name} добавлен в корзину`);
}

// Удалить товар
function removeFromCart(id) {
    let cart = getCart();
    cart = cart.filter(item => item.id !== id);
    saveCart(cart);
}

// Обновить количество
function updateCartQuantity(id, quantity) {
    let cart = getCart();
    const item = cart.find(item => item.id === id);
    if (item) {
        item.quantity = quantity;
        saveCart(cart);
    }
}

// Очистить корзину
function clearCart() {
    localStorage.removeItem(CART_KEY);
    updateCartBadge();
}

// Получить количество товаров
function getCartCount() {
    const cart = getCart();
    return cart.reduce((total, item) => total + item.quantity, 0);
}

// Обновить бейдж
function updateCartBadge() {
    const badge = document.getElementById('cartBadge');
    if (badge) {
        const count = getCartCount();
        badge.textContent = count;
        badge.style.display = count > 0 ? 'flex' : 'none';
    }
}

// Уведомление
function showNotification(message) {
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: var(--accent-green);
        color: var(--bg-dark);
        padding: 15px 25px;
        border-radius: 15px;
        font-weight: 600;
        z-index: 10000;
        animation: slideIn 0.3s ease;
        box-shadow: 0 5px 20px rgba(137, 255, 98, 0.4);
    `;
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.style.animation = 'fadeOut 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 2000);
}

// Инициализация при загрузке
document.addEventListener('DOMContentLoaded', updateCartBadge);
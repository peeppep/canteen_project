<?php
// Тест подключения к БД
require_once 'api/config/database.php';

try {
    $database = new Database();
    $db = $database->getConnection();
    echo "✓ Подключение к БД успешно!<br>";
    
    // Проверка товаров
    $query = "SELECT COUNT(*) as count FROM products";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $result = $stmt->fetch();
    
    echo "✓ В БД найдено товаров: " . $result['count'] . "<br>";
    
} catch (Exception $e) {
    echo "✗ Ошибка: " . $e->getMessage();
}
?>
